由于LCN 暂未发布适配 2.0 版本  
当前包是根据TCN transaction-springcloud 模块修改而来  
解决LCN 不兼容 Spring Cloud Finchley 问题

关于LCN  
https://github.com/codingapi/tx-lcn
