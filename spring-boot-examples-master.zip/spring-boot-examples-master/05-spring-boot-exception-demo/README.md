# SpringBoot Controller统一异常处理

---

该项目为SpringBoot Web应用对，针对所有Controller实现的统一异常处理，可以将异常锁死在后台应用，方便调用者的统一处理。