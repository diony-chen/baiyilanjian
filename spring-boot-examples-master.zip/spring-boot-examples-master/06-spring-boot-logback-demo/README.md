# SpringBoot Logback日志

---

SpringBoot项目默认使用Logback日志框架，正式项目上线我们需要将日志保存在指定的文件夹下。
根据类别、日期来保存日志，方便统计和查找。