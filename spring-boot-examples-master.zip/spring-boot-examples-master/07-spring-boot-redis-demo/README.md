# Spring Boot + Redis

- [x] Redis 基本配置与序列化
- [x] 发布订阅 Pub/Sub 示例