package com.example.paramstime;

import java.util.List;

/**
 * @author zhangfanghao
 * @version 1.0
 * @date 2019-12-02 22:17
 */
public class UserSaveForm {

    private List<User> userList;

    public List<User> getUserList() {
        return userList;
    }

    public void setUserList(List<User> userList) {
        this.userList = userList;
    }
}
