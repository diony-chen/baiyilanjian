# spring-boot-application-demo

---

本节介绍的是SpringBoot Application的相关知识，对Application类进行了深入分析。

示例代码主要针对SpringBoot项目启动过程中的一些自定义配置。

请参照对应教程进行学习:smile:
