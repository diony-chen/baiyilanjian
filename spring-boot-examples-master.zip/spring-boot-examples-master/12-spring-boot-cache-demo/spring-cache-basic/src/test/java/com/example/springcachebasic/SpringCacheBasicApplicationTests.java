package com.example.springcachebasic;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCacheBasicApplicationTests {

    @Test
    void contextLoads() {
    }

}
