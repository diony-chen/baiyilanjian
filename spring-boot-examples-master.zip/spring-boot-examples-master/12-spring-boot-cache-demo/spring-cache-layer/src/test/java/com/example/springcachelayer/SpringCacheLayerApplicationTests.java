package com.example.springcachelayer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCacheLayerApplicationTests {

    @Test
    void contextLoads() {
    }

}
