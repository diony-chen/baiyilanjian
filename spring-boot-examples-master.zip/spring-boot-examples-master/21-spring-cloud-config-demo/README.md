# Config Center Example

---

项目结构
- config-sever
- config-demo
- 服务注册中心

---

## config-server

## config-demo

## 服务注册中心

  - nacos: 项目原计划采用 nacos 作为服务注册中心，结果 config-demo 在接入 nacos 时出现启动失败的问题。
  - consul：正常
  - eureka：正常

