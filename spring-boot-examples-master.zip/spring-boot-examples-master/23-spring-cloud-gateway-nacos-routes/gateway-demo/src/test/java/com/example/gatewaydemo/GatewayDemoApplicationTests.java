package com.example.gatewaydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
