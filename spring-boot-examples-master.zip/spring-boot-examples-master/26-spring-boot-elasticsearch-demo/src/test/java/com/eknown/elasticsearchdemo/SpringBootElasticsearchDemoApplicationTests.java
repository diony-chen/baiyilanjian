package com.eknown.elasticsearchdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootElasticsearchDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
