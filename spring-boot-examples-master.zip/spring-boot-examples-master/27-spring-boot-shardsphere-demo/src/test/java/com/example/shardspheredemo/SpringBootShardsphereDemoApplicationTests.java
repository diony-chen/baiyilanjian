package com.example.shardspheredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootShardsphereDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
